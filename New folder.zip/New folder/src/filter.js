import React, { Component } from 'react'
export default class Filter extends Component {
    constructor(props) {
        super(props)
        this.state = {
            students: [
                { roll: 1, name: "Sunil", sub: "Math" },
                { roll: 2, name: "Rajkumar", sub: "English" },
                { roll: 3, name: "Anil", sub: "Coding" },
                { roll: 4, name: "Suman", sub: "Polital" },
                { roll: 5, name: "Ananya", sub: "React" },
                { roll: 6, name: "Sonali", sub: "Science" },
                { roll: 7, name: "Deepak", sub: "Angular" },
                { roll: 8, name: "Anita", sub: "History" },
                { roll: 9, name: "Gopal", sub: "Hindi" },
                { roll: 10, name: "Harsita", sub: "Html" }],
            search: ""
        }
    }
updateSearch(event) {
    this.setState({ search: event.target.value.substr(0, 20) })
}
addSomeData(event) {
    event.preventDefault()
    console.log(this.refs.name.value)
    let name = this.refs.name.value;
    let sub = this.refs.sub.value;
    let roll = this.refs.roll.value;
    this.setState({
        students: this.state.students.concat({ roll, name, sub })
    })
    console.log(this.state.students)
    this.refs.name.value = "";
    this.refs.sub.value = ""
    this.refs.roll.value = ""
}
render() {
    let filterData = this.state.students.filter((ele) => {
        return ele.name.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1 ||
            ele.roll == this.state.search ||
            ele.sub.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1
    }
    );

    return (
        <div className="filter">
            <input type="text" value={this.state.search}
                onChange={this.updateSearch.bind(this)} />
            <form onSubmit={this.addSomeData.bind(this)}>
                <input type="number" ref="roll" />
                <input type="text" ref="name" />
                <input type="text" ref="sub" />
                <button class=" btn btn-dark" type="submit">Add new Data</button>
            </form>
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Roll</th>
                        <th>Name</th>
                        <th>Sub</th>
                    </tr>
                </thead>
                <tbody>
                    {filterData.map((item, ind) => (
                        <tr key={item.roll}>
                            <td>{item.roll}</td>
                            <td>{item.name}</td>
                            <td>{item.sub}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}
}
